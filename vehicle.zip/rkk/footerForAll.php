<?php {?>

<link rel="stylesheet" type="text/css" href="footer.css"> 


	<div class = "footer">
		
	<span > 2022 © Gandhamardan Iron Ore Mines / Developed by Shri. Rajesh Ku. Khatua
	</span>


	</div>




<?php }?>